<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_All Categories        Alexa Skills  _a62561</name>
   <tag></tag>
   <elementGuidId>6cebf21b-ae4e-4e7e-b303-fa4e6ce1d586</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#searchDropdownBox</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='searchDropdownBox']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>f82ff18a-3858-41c2-9d4e-34c7f179a5ce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-describedby</name>
      <type>Main</type>
      <value>searchDropdownDescription</value>
      <webElementGuid>bd3a1dfb-10f5-4a05-941d-7a18c85fb938</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-search-dropdown searchSelect nav-progressive-attrubute nav-progressive-search-dropdown</value>
      <webElementGuid>7bd648b8-a7fc-4909-b049-5f7e73a14992</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-digest</name>
      <type>Main</type>
      <value>QLzJjdG9IZh17Us3VBQ9o6862kI=</value>
      <webElementGuid>26cd6eda-6c55-4548-a335-dbaa2b46dc4c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-selected</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>b887d328-a85e-461a-81b3-96426a8b124f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>searchDropdownBox</value>
      <webElementGuid>91537516-575c-4e7c-a8f8-f4b6e173e7cf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>url</value>
      <webElementGuid>1fd617a3-b4a9-4da9-b356-fcff3c33771e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>4ba2760a-3b7f-4cb7-8e99-f11880fbc027</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Search in</value>
      <webElementGuid>1a00a3ed-5663-4639-b2a1-70c4e14d5709</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        All Categories
        Alexa Skills
        Amazon Devices
        Amazon Fashion
        Amazon Fresh
        Amazon Pharmacy
        Appliances
        Apps &amp; Games
        Audible Audiobooks
        Baby
        Beauty
        Books
        Car &amp; Motorbike
        Clothing &amp; Accessories
        Collectibles
        Computers &amp; Accessories
        Electronics
        Furniture
        Garden &amp; Outdoors
        Gift Cards
        Grocery &amp; Gourmet Foods
        Health &amp; Personal Care
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Jewellery
        Kindle Store
        Luggage &amp; Bags
        Luxury Beauty
        Movies &amp; TV Shows
        Music
        Musical Instruments
        Office Products
        Pet Supplies
        Prime Video
        Shoes &amp; Handbags
        Software
        Sports, Fitness &amp; Outdoors
        Subscribe &amp; Save
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under ₹500
        Video Games
        Watches
    </value>
      <webElementGuid>6e791b59-a2cd-4c48-802d-3d269ab2e384</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;searchDropdownBox&quot;)</value>
      <webElementGuid>a259fa34-2bf3-4472-bc06-4edbe0c4d78b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='searchDropdownBox']</value>
      <webElementGuid>61091829-51b1-4db9-b0f8-81bafdf26d79</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-search-dropdown-card']/div/select</value>
      <webElementGuid>f6d0e5d7-ade0-4ea4-b5f2-4c9a3f17794e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>c0d319ea-8c02-4639-a838-b184bc0da5a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@id = 'searchDropdownBox' and @name = 'url' and @title = 'Search in' and (text() = '
        All Categories
        Alexa Skills
        Amazon Devices
        Amazon Fashion
        Amazon Fresh
        Amazon Pharmacy
        Appliances
        Apps &amp; Games
        Audible Audiobooks
        Baby
        Beauty
        Books
        Car &amp; Motorbike
        Clothing &amp; Accessories
        Collectibles
        Computers &amp; Accessories
        Electronics
        Furniture
        Garden &amp; Outdoors
        Gift Cards
        Grocery &amp; Gourmet Foods
        Health &amp; Personal Care
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Jewellery
        Kindle Store
        Luggage &amp; Bags
        Luxury Beauty
        Movies &amp; TV Shows
        Music
        Musical Instruments
        Office Products
        Pet Supplies
        Prime Video
        Shoes &amp; Handbags
        Software
        Sports, Fitness &amp; Outdoors
        Subscribe &amp; Save
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under ₹500
        Video Games
        Watches
    ' or . = '
        All Categories
        Alexa Skills
        Amazon Devices
        Amazon Fashion
        Amazon Fresh
        Amazon Pharmacy
        Appliances
        Apps &amp; Games
        Audible Audiobooks
        Baby
        Beauty
        Books
        Car &amp; Motorbike
        Clothing &amp; Accessories
        Collectibles
        Computers &amp; Accessories
        Electronics
        Furniture
        Garden &amp; Outdoors
        Gift Cards
        Grocery &amp; Gourmet Foods
        Health &amp; Personal Care
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Jewellery
        Kindle Store
        Luggage &amp; Bags
        Luxury Beauty
        Movies &amp; TV Shows
        Music
        Musical Instruments
        Office Products
        Pet Supplies
        Prime Video
        Shoes &amp; Handbags
        Software
        Sports, Fitness &amp; Outdoors
        Subscribe &amp; Save
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under ₹500
        Video Games
        Watches
    ')]</value>
      <webElementGuid>07eafb86-3862-4b76-ba1e-434881a5a6b8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
