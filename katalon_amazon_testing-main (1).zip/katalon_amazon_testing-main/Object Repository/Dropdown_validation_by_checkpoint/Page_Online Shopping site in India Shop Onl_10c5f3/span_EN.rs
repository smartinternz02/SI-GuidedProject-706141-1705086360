<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_EN</name>
   <tag></tag>
   <elementGuidId>920427b0-edd9-4488-b134-aa762e5d23da</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.icp-nav-link-inner > span.nav-line-2</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='icp-nav-flyout']/span/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>009345da-0222-4ea9-af5d-cb3d4183841f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-line-2</value>
      <webElementGuid>bc67cfa1-a1aa-4ed6-914a-73a927cf4d4f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
          EN
        
      </value>
      <webElementGuid>c1101d7e-d5cc-4c23-8781-2b7c77369ba3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;icp-nav-flyout&quot;)/span[@class=&quot;icp-nav-link-inner&quot;]/span[@class=&quot;nav-line-2&quot;]</value>
      <webElementGuid>421e2120-ac2d-4b14-8b68-4b01254793ce</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//a[@id='icp-nav-flyout']/span/span[2]</value>
      <webElementGuid>086d8c1f-74dd-4b15-9538-178f16b3c6a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/span[2]</value>
      <webElementGuid>d519faa4-c6cc-4aa3-ae68-a79848a7b5b5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
        
          EN
        
      ' or . = '
        
          EN
        
      ')]</value>
      <webElementGuid>5bfca4f1-97e4-44ba-9255-fd76c954adfe</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
